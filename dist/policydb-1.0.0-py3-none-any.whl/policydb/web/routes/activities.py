"""Activity and renewal routes."""

from __future__ import annotations

from collections import defaultdict
from datetime import date, datetime

from fastapi import APIRouter, Depends, Form, Request
from fastapi.responses import HTMLResponse, RedirectResponse

from policydb import config as cfg
from policydb.queries import (
    get_activities,
    get_activity_by_id,
    get_all_followups,
    get_renewal_pipeline,
)
from policydb.web.app import get_db, templates

router = APIRouter()


@router.post("/activities/log", response_class=HTMLResponse)
def activity_log(
    request: Request,
    client_id: int = Form(...),
    policy_id: int = Form(0),
    activity_type: str = Form(...),
    subject: str = Form(...),
    details: str = Form(""),
    contact_person: str = Form(""),
    follow_up_date: str = Form(""),
    conn=Depends(get_db),
):
    account_exec = cfg.get("default_account_exec", "Grant")
    cursor = conn.execute(
        """INSERT INTO activity_log
           (activity_date, client_id, policy_id, activity_type, contact_person, subject, details, follow_up_date, account_exec)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
        (date.today().isoformat(), client_id, policy_id or None, activity_type,
         contact_person or None, subject, details or None,
         follow_up_date or None, account_exec),
    )
    conn.commit()
    # Return the new activity row as HTMX partial
    row = conn.execute(
        """SELECT a.*, c.name AS client_name, p.policy_uid
           FROM activity_log a
           JOIN clients c ON a.client_id = c.id
           LEFT JOIN policies p ON a.policy_id = p.id
           WHERE a.id = ?""",
        (cursor.lastrowid,),
    ).fetchone()
    a = dict(row)
    return templates.TemplateResponse("activities/_activity_row.html", {
        "request": request,
        "a": a,
    })


@router.post("/activities/{activity_id}/complete", response_class=HTMLResponse)
def activity_complete(request: Request, activity_id: int, conn=Depends(get_db)):
    conn.execute(
        "UPDATE activity_log SET follow_up_done=1 WHERE id=?", (activity_id,)
    )
    conn.commit()
    # Return empty element to remove from overdue list on dashboard,
    # or updated row on client detail
    return HTMLResponse("")


@router.get("/followups", response_class=HTMLResponse)
def followups_page(
    request: Request,
    window: int = 30,
    activity_type: str = "",
    q: str = "",
    conn=Depends(get_db),
):
    overdue, upcoming = get_all_followups(conn, window=window)

    if activity_type:
        overdue  = [r for r in overdue  if r["activity_type"] == activity_type]
        upcoming = [r for r in upcoming if r["activity_type"] == activity_type]
    if q:
        q_lower = q.lower()
        overdue  = [r for r in overdue  if q_lower in r["client_name"].lower()]
        upcoming = [r for r in upcoming if q_lower in r["client_name"].lower()]

    return templates.TemplateResponse("followups.html", {
        "request": request,
        "active": "followups",
        "overdue": overdue,
        "upcoming": upcoming,
        "window": window,
        "activity_type": activity_type,
        "q": q,
        "activity_types": cfg.get("activity_types", []),
    })


@router.get("/activities", response_class=HTMLResponse)
def activity_list(
    request: Request,
    days: int = 90,
    activity_type: str = "",
    client_id: int = 0,
    conn=Depends(get_db),
):
    rows = [dict(r) for r in get_activities(
        conn, days=days,
        client_id=client_id or None,
        activity_type=activity_type or None,
    )]
    overdue, _ = get_all_followups(conn, window=0)
    all_clients = conn.execute(
        "SELECT id, name FROM clients WHERE archived=0 ORDER BY name"
    ).fetchall()
    return templates.TemplateResponse("activities/list.html", {
        "request": request,
        "active": "activities",
        "activities": rows,
        "overdue": overdue,
        "days": days,
        "activity_type": activity_type,
        "client_id": client_id,
        "activity_types": cfg.get("activity_types", []),
        "all_clients": [dict(c) for c in all_clients],
    })


_URGENCY_ORDER = ["EXPIRED", "URGENT", "WARNING", "UPCOMING", "OK"]


@router.get("/renewals/calendar", response_class=HTMLResponse)
def renewals_calendar(request: Request, conn=Depends(get_db)):
    rows = get_renewal_pipeline(conn, window_days=365)

    months: dict = defaultdict(list)
    for p in rows:
        d = dict(p)
        client_row = conn.execute(
            "SELECT id FROM clients WHERE name=?", (d["client_name"],)
        ).fetchone()
        d["client_id"] = client_row["id"] if client_row else 0
        months[d["expiration_date"][:7]].append(d)

    calendar = []
    for month_key in sorted(months.keys()):
        policies = months[month_key]
        urgencies = [p["urgency"] for p in policies]
        worst = min(urgencies, key=lambda u: _URGENCY_ORDER.index(u) if u in _URGENCY_ORDER else 99)
        calendar.append({
            "month_key": month_key,
            "month_label": datetime.strptime(month_key, "%Y-%m").strftime("%B %Y"),
            "policies": policies,
            "policy_count": len(policies),
            "total_premium": sum(p["premium"] or 0 for p in policies),
            "worst_urgency": worst,
        })

    return templates.TemplateResponse("renewals_calendar.html", {
        "request": request,
        "active": "renewals",
        "calendar": calendar,
    })


@router.get("/renewals/export")
def renewals_export(window: int = 180, fmt: str = "xlsx", conn=Depends(get_db)):
    from fastapi.responses import Response
    from policydb.exporter import export_renewals_csv, export_renewals_xlsx
    today = date.today().isoformat()
    if fmt == "xlsx":
        content = export_renewals_xlsx(conn, window_days=window)
        return Response(
            content=content,
            media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            headers={"Content-Disposition": f'attachment; filename="renewals_{today}.xlsx"'},
        )
    content = export_renewals_csv(conn, window_days=window)
    return Response(
        content=content,
        media_type="text/csv",
        headers={"Content-Disposition": f'attachment; filename="renewals_{today}.csv"'},
    )


@router.get("/renewals", response_class=HTMLResponse)
def renewals(request: Request, window: int = 180, urgency: str = "", status: str = "", conn=Depends(get_db)):
    rows = get_renewal_pipeline(
        conn,
        window_days=window,
        urgency=urgency or None,
        renewal_status=status or None,
    )

    # Attach client_id for linking
    pipeline = []
    for p in rows:
        d = dict(p)
        client_row = conn.execute(
            "SELECT id FROM clients WHERE name=?", (d["client_name"],)
        ).fetchone()
        d["client_id"] = client_row["id"] if client_row else 0
        pipeline.append(d)

    return templates.TemplateResponse("renewals.html", {
        "request": request,
        "active": "renewals",
        "rows": pipeline,
        "window": window,
        "urgency": urgency,
        "status": status,
        "renewal_statuses": cfg.get("renewal_statuses"),
    })
